package com.automation;

public interface commonMethodObject {
  //Check type of Array, 1-D Array or 2-D Array
  public int checkTypeOfArray(Object Array);
}