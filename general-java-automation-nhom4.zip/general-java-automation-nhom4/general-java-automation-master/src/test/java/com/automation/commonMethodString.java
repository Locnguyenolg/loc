package com.automation;

import java.util.List;

public interface commonMethodString {
      // Check if string is correct format
      public List checkString(String str);

      //Check if string is Integer
      public boolean isInteger(String s);
}
